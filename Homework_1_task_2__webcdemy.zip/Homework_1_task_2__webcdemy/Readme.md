# Hi there! I'm Ksenia!
____
### Currently I'm an intern at a small company in Netheland. I'm styding frontend for 1 month.
### My level of english is B2, but in nearest future I want to confirm C1. 
____
## My soft skills are:
* ### Communicative
* ### Disciplined
* ### Creative 
* ### I bring everything to an end
____
## My hard skills are not impressive (for now):
* ### I know ***python*** bases.
* ### I have learned some bases of ***html*** and ***css***.
___
## In conclusion I want to say that, I'm really enjoing learnin. And I will do everything, so my *hard skill* list could be much bigger! Thaks for your time.
## You can contact me on this e-mail adress: __kseniapopova02@gmail.com__
## Bye!
 

  
