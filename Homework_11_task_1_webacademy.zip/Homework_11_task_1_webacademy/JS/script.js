function getHandShakes(handShakes) {
    //people in the room from the beginning.
    let peopleInRoom = 1;
    //hand shakes from the beginning
    let handsShook = 0;

    while (handShakes > handsShook) {
        handsShook = handsShook + peopleInRoom
        console.log(peopleInRoom);
        peopleInRoom++;

    }
}
 getHandShakes(10);

 