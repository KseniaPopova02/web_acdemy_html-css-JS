#My name is Ksenia
##I'm 19 years old, currentle I'm styding in Kharkiv university of **building and architecture**.
##My _main_ goal: become a frontend developer