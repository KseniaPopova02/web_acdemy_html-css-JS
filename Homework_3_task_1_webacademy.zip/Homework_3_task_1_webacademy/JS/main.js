//function is adding zeros at the start
//if the number is less than ten, it will be adding a zero before the number)
function zero_first_format(value)
{
    if (value < 10) {
        value='0'+value;
    } return value; 
}




function join(t, a, s) {
    function format(m) {
       let f = new Intl.DateTimeFormat('en', m);
       return f.format(t);
    }
    return a.map(format).join(s);
 }
 
 
 let a = [{day: 'numeric'}, {month: 'long'}, {year: 'numeric'}];
 let b = [{month: 'long'}, {year: 'numeric'}];
 let s = join(new Date, a, ' ');
 let t = join(new Date, b, ' ');
 console.log(s);
 var dateHeader = document.querySelector(".left-header-data");
dateHeader.innerHTML = s;

var dateRight = document.querySelector(".right-data");
dateRight.innerHTML = t;
